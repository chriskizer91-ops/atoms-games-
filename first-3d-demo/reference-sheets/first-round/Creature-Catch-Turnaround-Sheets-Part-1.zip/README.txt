Creature Catch 3D — Turnaround reference sheets

17 PNG sheets generated from the original sprites embedded in creature-catch-v7.html, following the supplied turnaround prompt document. Clovermouse includes the corrected diagonal view directions.

These are enlarged modeling references. The PNGs retain the generator's full resolution; native 64x64, 48x80 and 48x48 per-view dimensions, an exact 16-color palette, and an exact #FF00FF chroma key are not guaranteed. Pixel colors and scale need normalization if these are later repurposed as game sprites.

Generation method: built-in image generation with original sprite references. See generation-prompts.md for the prompt set.
